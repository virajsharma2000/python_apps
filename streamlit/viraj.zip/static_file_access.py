import streamlit as st

url = "https://pydelhi.org/blog/theme/images/logo-color.png"
url = "./viraj.jpg"
st.image(url, caption="Image from URL")