import streamlit as st

st.title("Custom Theme Example")
st.write("This app uses a custom theme defined in the `config.toml` file.")
st.button("Click Me")